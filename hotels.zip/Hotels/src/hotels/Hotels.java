/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hotels;

import java.util.Scanner;

/**
 *
 * @author hi
 */
public class Hotels {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    int qw;
    Scanner ob=new Scanner(System.in);
    
   pass A=new pass();
     A.passw();
    
   if(A.w==1)
      {
         System.out.print("if you want to enter foods prices:\n  press 1...!!");
         qw=ob.nextInt(); 
         if(qw==1)
         {
             Bill m;
             m = new Bill();
         }
         else{
            // System.out.println("\n under constructions");
            foods v;
            v=new foods();
           
         }
             }
    }
}


   class Bill {

        public Bill()
    {
    valueChange();
    }
    private void valueChange()
    { Scanner o=new Scanner(System.in);
    int j;
    String arr[];
    int arr1[];
   // float arr2[] = null;
        arr1=new int[50];
        arr = new String[50];
       System.out.println("how many products are willing to enter:");
        int mu=o.nextInt();
        int qw;
          for(qw=0;qw<=mu;qw++)
          {   if(qw==0)
          {  
              System.out.println("start entering the details");
          } 
          else
          {
              System.out.print("enter the "+ (qw) +"product:");
              arr[qw]=o.nextLine();
          }

          } 
          for(qw=0;qw<=mu;qw++)
          {
              if(qw==0)
              {
              continue;
              }
              System.out.println("");
              System.out.print("enter the price of "+ arr[qw] +"product:");
              arr1[qw]=o.nextInt();
              //arr2[qw]=float.parseFloat(arr1[qw]);
              
          }
          System.out.println("\n if u want to view the list of products: press '1' for view it or else press '0' for exit it...!!");
              int view=o.nextInt();
              if(view==1)
              {
              for(qw=0;qw<=mu;qw++)
              {
                  
                  if(qw==0)
                  {
                  continue;
                  }
              System.out.println("THE PRICE OF"+ arr[qw] +"is"+ arr1[qw]);
              
              }
              }
              System.out.println("if you want to change the price of the existing foods \n press 1 to change...!");
        j=o.nextInt();  
        if(j==1)
        {
            for(int qe=0;qe<=mu;qe++)
            {
        
        {
        }
        }
    }
    }
    }

 
class foods extends Bill 
{ 
    public foods()
{
food();
print();
}
private void food()
{
//    int[] arra = new int[50];
    System.out.print("foods list");
       int ne = 0;
  /*  for(int i=1;i<=ne;i++)
    {
        String[] arr = null;
        int qw = 0;
        String[] arr1 = null;
        System.out.println("is" +arr1[qw]+ "THE PRICE OF"+ arr[qw]");
    }*/
}
private void  print()
{
}
}

class pass
{
    int r=0,q=0;
    int Pas;
    int k=121211;
    int m=121112;
    int s=121111;
    String username,ed;
    Scanner obj=new Scanner(System.in);
    int w,e,z=4;
    void passw()
    {
    System.out.println("enter the user name:");
    username=obj.nextLine();
    w=0;
    
    q=userName(username);
    }
    int t=0;
    
    private int userName(String username)
    { 
      if("".equals(username))
      {
          System.out.println("plz enter the user id dont click empty textname");
          passw();
      }
      else {
          switch (username) {
              
              case "karthik":
                  t=1;
                  run(username);
                  break;
              case "mano":
                  t=1;
                  run(username);
                  break;
              case "shiva":
                  t=1;
                  run(username);
                  break;
              default:
                  System.out.println("enter the valid user id");
                  passw();
                  break;
                  
          }
      }
        return 0;   
    }
    void run(String username)
    {
        if(t==1)
    {
        System.out.println("enter the password:");
   Pas=obj.nextInt();
    w=passwor(Pas,username);
    }
    }
int passwor(int pas,String username)
{int b,u;
    String end=String.valueOf(pas);
    b=swi(end,username);
    
 if(1==b)
 {
     u=1;
 }
 else
 {
     u=0;
     
 }
 return u;
}
    int swi(String end,String username){
      int qp=0;
        z--;
             if(("karthik".equals(username) && "121211".equals(end))||("mano".equals(username)&&"121233".equals(end))||("121222".equals(end)&&"shiva".equals(username)))
         {
             System.out.println("welcome");
             z = -1;
       
         }
            if(z>=1)
        { 
              System.out.println("you have "+(z)+" chance:");
            run(username);
                   }
              if(z==0)
        {
         System.out.println("plz call the admin..");
            admin(username);
                 
        }
        if(z==-1)
        {
            qp=1;
        }
             if(qp==1)
             {
                 return 1;
             }
             else
             {
                 return 0;
             }
             
    
    }              
    
    int admin(String username)
    {
        System.out.println("not founded");
        return 0;
    }
    
    }

    
  
    

 
    

        


   



 /*public class billo()
{
  private void bil()
            {
           int w;
           int item;
           double sum = 0;
                   
for(w=1;w<=n;w++)
{
           do{
               switch(item)
               {
                   case 1:
                   { 
                     int idly=arr[y];
                       sum=sum+idly;
                   }
               }
           }
            }
}*/
    
    

                