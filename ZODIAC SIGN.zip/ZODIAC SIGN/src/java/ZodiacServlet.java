/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author hi
 */
public class ZodiacServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
           String sign=request.getParameter("sign");
           int date=Integer.parseInt(sign);
           String mon=request.getParameter("birth");
           int month=Integer.parseInt(mon);
          // out.print(date);
           //out.print(month);
           out.print("<html><head><title>ZODIAC SIGN</title></head>");
           out.print("<body background=\"+zodiac.png+\">");
           if((date<=31)&&(month<=12))
           {
          if((date>=21)&&(month==3)||(date<=20)&&(month==4))
        {
            out.print("YOU ARIES AND YOUR BIRTHSTONE IS BLUESTONE");
        }
        if((date>=21)&&(month==4)||(date<=21)&&(month==5))
        {
               out.print("YOU TAURUS AND YOUR BIRTHSTONE IS SAPPHIRE");
        }
          if((date>=22)&&(month==5)||(date<=21)&&(month==6))
        {
               out.print("YOU GEMINI AND YOUR BIRTHSTONE IS AGATE");
        }
            if((date>=22)&&(month==6)||(date<=22)&&(month==7))
        {
               out.print("YOU CANCER AND YOUR BIRTHSTONE IS EMERALD");
        }
              if((date>=23)&&(month==7)||(date<=22)&&(month==8))
        {
               out.print("YOU LEO AND YOUR BIRTHSTONE IS ONYX");
        }
                if((date>=23)&&(month==8)||(date<=22)&&(month==9))
        {
               out.print("YOU VIRGO AND YOUR BIRTHSTONE IS CARNELIAN");
        }
                if((date>=23)&&(month==9)||(date<=23)&&(month==10))
        {
               out.print("YOU LIBRA AND YOUR BIRTHSTONE IS CHRYSOLITE");
        }
          if((date>=24)&&(month==10)||(date<=21)&&(month==11))
        {
               out.print("YOU SCORPIO AND YOUR BIRTHSTONE IS BERYL");
        }
            if((date>=22)&&(month==11)||(date<=21)&&(month==12))
        {
               out.print("YOU SAGITTARIUS AND YOUR BIRTHSTONE IS TOPAZ");
        }
              if((date>=22)&&(month==12)||(date<=21)&&(month==1))
        {
               System.out.print("YOU CAPRICORN AND YOUR BIRTHSTONE IS RUBY");
        }
                if((date>=22)&&(month==1)||(date<=18)&&(month==2))
        {
               out.print("YOU AQUARIES AND YOUR BIRTHSTONE IS GARNET");
        }
                  if((date>=19)&&(month==2)||(date<=20)&&(month==3))
        {
               out.print("YOU PISCES AND YOUR BIRTHSTONE IS AMETHYST");
        }
        }
           else
           {
               out.print("ENTER THE VALID DATE AND MONTH");
               
    }
           out.print("</body></html>");
    }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
